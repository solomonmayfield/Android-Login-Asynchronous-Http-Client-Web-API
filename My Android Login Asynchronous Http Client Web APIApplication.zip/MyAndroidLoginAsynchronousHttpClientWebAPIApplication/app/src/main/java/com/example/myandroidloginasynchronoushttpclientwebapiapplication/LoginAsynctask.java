package com.example.myandroidloginasynchronoushttpclientwebapiapplication;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.SyncHttpClient;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

/**
 *Android Login Asynchronous Http Client Web API
 * @Author Solomon Mayfield
 *Login process using Asynchronous Http Client Web API codeigniter rest server
 * please visit before this video for create an web API
 * Rest Server Codeigniter Integrated With Android Prepared API 
 *
 *
 */




public class LoginAsynctask extends AsyncTask<Void, Void, String> {

    private String username;
    private String password;
    boolean obj;
    String Msg;
    Context context;


    public LoginAsynctask(String username, String password, boolean obj, String msg, Context context) {
        this.username = username;
        this.password = password;
        this.obj = obj;
        Msg = msg;
        this.context = context;
    }

    public LoginAsynctask(String usename, String password) {
    }

    public LoginAsynctask(String usename, String password, Context applicationContext) {
    }

    @Override
    protected String doInBackground(Void... voids) {
        return this.sendLogin();
    }

    private String sendLogin() {

        final String result[] = {null};
        String URL_API = BuildConfig.BASE_URL + "users";
        SyncHttpClient client = new SyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("?page=2", username);
        params.put("key", password);

        client.get(URL_API, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    result[0] = new String(responseBody);
                }catch (Exception e){

                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });

        return result[0];
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        try{
            JSONObject jsonObject = new JSONObject(s);
            obj =jsonObject.getBoolean("status");
            if (!obj){
                Msg = jsonObject.getString("error");
            }

        }catch (JSONException e){
            e.printStackTrace();
        }
        if (!obj){
            Toast.makeText(context, Msg,Toast.LENGTH_LONG).show();
            }else{
            Toast.makeText(context, "Success",Toast.LENGTH_LONG).show();
        }


    }
}
